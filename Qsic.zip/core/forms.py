# from django import forms
# from django.db.transaction import commit
#
# from core.models import artist
# from core.models import album
# from core.models import song
# from django.contrib.auth.forms import UserCreationForm
#
#
# class song(song):
#     def save(self, *args, **kwargs):
#         if not commit:
#             raise NotImplementedError("Can't create User and Userextended without database save")
#             artist.save()
#             album.name.add(self.cleaned_data['rolle'])
#             album.save()
#         return song
